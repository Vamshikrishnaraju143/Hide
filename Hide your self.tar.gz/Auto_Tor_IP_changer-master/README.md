# Auto_Tor_IP_changer V 2.1
change your Ip Address automatically  This tool based on tor project


how to install this tools :

* : requirements:

  sudo apt-get install tor
  pip3 install requests[socks]
  or just run autoTor it will install everything

1: git clone https://github.com/FDX100/Auto_Tor_IP_changer.git

2 : cd Auto_Tor_IP_changer

3 : python3 install.py

4 : interminal type ( aut ) any where you want
  
5 : type time to change IP

6: type how many time to change your ip 

*[0 to infinte IP change]

6 : go to your browser / pc  change sock proxy to 127.0.0.1:9050

7 : BOOOOOOMM 

============
http://facebook.com/ninja.hackerz.kurdish/
